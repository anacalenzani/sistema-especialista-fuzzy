classdef interface_sef < matlab.apps.AppBase

    % Properties that correspond to app components
    properties (Access = public)
        UIFigure                    matlab.ui.Figure
        dicasLabel                  matlab.ui.control.Label
        dicasTextArea               matlab.ui.control.TextArea
        backgroundTextArea          matlab.ui.control.TextArea
        proximoButton               matlab.ui.control.Button
        anteriorButton              matlab.ui.control.Button
        salvarButton                matlab.ui.control.Button
        executarButton              matlab.ui.control.Button
        TabGroup                    matlab.ui.container.TabGroup
        IntroducaoTab               matlab.ui.container.Tab
        GridLayout4                 matlab.ui.container.GridLayout
        Hyperlink                   matlab.ui.control.Hyperlink
        Label_9                     matlab.ui.control.Label
        Label_8                     matlab.ui.control.Label
        Label_7                     matlab.ui.control.Label
        Label_6                     matlab.ui.control.Label
        Label_5                     matlab.ui.control.Label
        Label_4                     matlab.ui.control.Label
        Label_3                     matlab.ui.control.Label
        Label_2                     matlab.ui.control.Label
        Label_1                     matlab.ui.control.Label
        Parte1Tab                   matlab.ui.container.Tab
        GridLayout                  matlab.ui.container.GridLayout
        divisoriaLabel_1            matlab.ui.control.Label
        camDefinidaTooltip          matlab.ui.control.Label
        camDefinidaPanel            matlab.ui.container.Panel
        camDefinidaSlider           matlab.ui.control.Slider
        camDefinidaDropDown         matlab.ui.control.DropDown
        slider2dropButton_3         matlab.ui.control.Button
        camDefinidaLabel            matlab.ui.control.Label
        tamanhoTooltip              matlab.ui.control.Label
        tamanhoPanel                matlab.ui.container.Panel
        tamanhoSwitch               matlab.ui.control.Switch
        tamanhoLabel                matlab.ui.control.Label
        recursosPTZTooltip          matlab.ui.control.Label
        recursosPTZPanel            matlab.ui.container.Panel
        recursosPTZSwitch           matlab.ui.control.Switch
        recursosPTZLabel            matlab.ui.control.Label
        definicaoPreviaTooltip      matlab.ui.control.Label
        definicaoPreviaPanel        matlab.ui.container.Panel
        definicaoPreviaSwitch       matlab.ui.control.Switch
        definicaoPreviaLabel        matlab.ui.control.Label
        tempoMonitoramentoTooltip   matlab.ui.control.Label
        tempoMonitoramentoPanel     matlab.ui.container.Panel
        tempoMonitoramentoDropDown  matlab.ui.control.DropDown
        tempoMonitoramentoSlider    matlab.ui.control.Slider
        slider2dropButton_2         matlab.ui.control.Button
        distanciaTooltip            matlab.ui.control.Label
        distanciaPanel              matlab.ui.container.Panel
        distanciaDropDown           matlab.ui.control.DropDown
        distanciaSlider             matlab.ui.control.Slider
        slider2dropButton_1         matlab.ui.control.Button
        Parte2Tab                   matlab.ui.container.Tab
        GridLayout_2                matlab.ui.container.GridLayout
        divisoriaLabel_2            matlab.ui.control.Label
        biomaTooltip                matlab.ui.control.Label
        biomaPanel                  matlab.ui.container.Panel
        biomaDropDown               matlab.ui.control.DropDown
        biomaLabel                  matlab.ui.control.Label
        redeMovelTooltip            matlab.ui.control.Label
        redeMovelPanel              matlab.ui.container.Panel
        redeMovelSlider             matlab.ui.control.Slider
        redeMovelDropDown           matlab.ui.control.DropDown
        slider2dropButton_6         matlab.ui.control.Button
        redeMovelLabel              matlab.ui.control.Label
        preferenciaTooltip          matlab.ui.control.Label
        preferenciaPanel            matlab.ui.container.Panel
        preferenciaSwitch           matlab.ui.control.Switch
        preferenciaLabel            matlab.ui.control.Label
        wifiTooltip                 matlab.ui.control.Label
        wifiPanel                   matlab.ui.container.Panel
        wifiLabel                   matlab.ui.control.Label
        wifiSwitch                  matlab.ui.control.Switch
        nivelSombreamentoTooltip    matlab.ui.control.Label
        nivelSombreamentoPanel      matlab.ui.container.Panel
        nivelSombreamentoSlider     matlab.ui.control.Slider
        nivelSombreamentoDropDown   matlab.ui.control.DropDown
        slider2dropButton_5         matlab.ui.control.Button
        incidenciaSolarTooltip      matlab.ui.control.Label
        incidenciaSolarPanel        matlab.ui.container.Panel
        incidenciaSolarSlider       matlab.ui.control.Slider
        incidenciaSolarDropDown     matlab.ui.control.DropDown
        slider2dropButton_4         matlab.ui.control.Button
        Parte3Tab                   matlab.ui.container.Tab
        GridLayout2                 matlab.ui.container.GridLayout
        divisioriaLabel_3           matlab.ui.control.Label
        estacaoCarregamentoTooltip  matlab.ui.control.Label
        estacaoCarregamentoPanel    matlab.ui.container.Panel
        estacaoCarregamentoSwitch   matlab.ui.control.Switch
        estacaoCarregamentoLabel    matlab.ui.control.Label
        autonomiaTooltip            matlab.ui.control.Label
        autonomiaPanel              matlab.ui.container.Panel
        autonomiaDropDown           matlab.ui.control.DropDown
        autonomiaSlider             matlab.ui.control.Slider
        slider2dropButton_7         matlab.ui.control.Button
        raspTooltip                 matlab.ui.control.Label
        raspPanel                   matlab.ui.container.Panel
        raspSwitch                  matlab.ui.control.Switch
        raspLabel                   matlab.ui.control.Label
        telemetriaTooltip           matlab.ui.control.Label
        telemetriaPanel             matlab.ui.container.Panel
        telemetriaSwitch            matlab.ui.control.Switch
        telemetriaLabel             matlab.ui.control.Label
        ResultadosTab               matlab.ui.container.Tab
        GridLayout3                 matlab.ui.container.GridLayout
        tipoConexaoPanel            matlab.ui.container.Panel
        tipoConexaoLabel            matlab.ui.control.Label
        tipoBateriaPanel            matlab.ui.container.Panel
        inversorLabel               matlab.ui.control.Label
        controladorLabel            matlab.ui.control.Label
        tipoBateriaLabel            matlab.ui.control.Label
        tipoModuloLabel             matlab.ui.control.Label
        tipoTelemetriaPanel         matlab.ui.container.Panel
        tipoTelemetriaLabel         matlab.ui.control.Label
        cameraPanel                 matlab.ui.container.Panel
        obsLabel                    matlab.ui.control.Label
        tipoCameraLabel             matlab.ui.control.Label
        porteCameraLabel            matlab.ui.control.Label
    end

    
    methods (Access = private)
        
        function inputs = leitura_entradas(app,fistree)
            
            if app.distanciaDropDown.Visible == 1
                if app.distanciaDropDown.Value == "curta"
                    i1 = fistree.FIS(1).Inputs(1).MembershipFunctions(1).Parameters(2);
                elseif app.distanciaDropDown.Value == "média"
                    i1 = fistree.FIS(1).Inputs(1).MembershipFunctions(2).Parameters(2);
                elseif app.distanciaDropDown.Value == "longa"
                    i1 = fistree.FIS(1).Inputs(1).MembershipFunctions(3).Parameters(2);
                end
            elseif app.distanciaSlider.Visible == 1
                i1 = app.distanciaSlider.Value;
            end

            i2=app.recursosPTZSwitch.Value;

            i3=app.tamanhoSwitch.Value;

            i4=app.definicaoPreviaSwitch.Value;
            
            
            if app.camDefinidaDropDown.Visible == 1
                if app.camDefinidaDropDown.Value == "baixa"
                    i5 = fistree.FIS(2).Inputs(3).MembershipFunctions(1).Parameters(2);
                elseif app.camDefinidaDropDown.Value == "média"
                    i5 = fistree.FIS(2).Inputs(3).MembershipFunctions(2).Parameters(2);
                elseif app.camDefinidaDropDown.Value == "alta"
                    i5 = fistree.FIS(2).Inputs(3).MembershipFunctions(3).Parameters(2);
                end
            elseif app.camDefinidaSlider.Visible == 1
                i5=app.camDefinidaSlider.Value;
            end

            i6=app.biomaDropDown.Value;
            if i6 == "Amazônia"
                i6 = fistree.FIS(3).Inputs(1).MembershipFunctions(1).Parameters(2);
            elseif i6 == "Mata Atlântica"
                i6 = fistree.FIS(3).Inputs(1).MembershipFunctions(2).Parameters(2);
            elseif i6 == "Pantanal"
                i6 = fistree.FIS(3).Inputs(1).MembershipFunctions(3).Parameters(2);
            elseif i6 == "Pampa"
                i6 = fistree.FIS(3).Inputs(1).MembershipFunctions(4).Parameters(2);
            elseif i6 == "Cerrado"
                i6 = fistree.FIS(3).Inputs(1).MembershipFunctions(5).Parameters(2);
            elseif i6 == "Caatinga"
                i6 = fistree.FIS(3).Inputs(1).MembershipFunctions(6).Parameters(2);
            end

            if app.incidenciaSolarDropDown.Visible == 1
                if app.incidenciaSolarDropDown.Value == "muito curto"
                    i7 = fistree.FIS(3).Inputs(2).MembershipFunctions(1).Parameters(2);
                elseif app.incidenciaSolarDropDown.Value == "curto"
                    i7 = fistree.FIS(3).Inputs(2).MembershipFunctions(2).Parameters(2);
                elseif app.incidenciaSolarDropDown.Value == "médio"
                    i7 = fistree.FIS(3).Inputs(2).MembershipFunctions(3).Parameters(2);
                elseif app.incidenciaSolarDropDown.Value == "longo"
                    i7 = fistree.FIS(3).Inputs(2).MembershipFunctions(4).Parameters(2);
                end
            elseif app.incidenciaSolarSlider.Visible == 1
                i7 = app.incidenciaSolarSlider.Value;
            end

            if app.nivelSombreamentoDropDown.Visible == 1
                if app.nivelSombreamentoDropDown.Value == "muito baixo"
                    i8 = fistree.FIS(3).Inputs(3).MembershipFunctions(1).Parameters(2);
                elseif app.nivelSombreamentoDropDown.Value == "baixo"
                    i8 = fistree.FIS(3).Inputs(3).MembershipFunctions(2).Parameters(2);
                elseif app.nivelSombreamentoDropDown.Value == "médio"
                    i8 = fistree.FIS(3).Inputs(3).MembershipFunctions(3).Parameters(2);
                elseif app.nivelSombreamentoDropDown.Value == "alto"
                    i8 = fistree.FIS(3).Inputs(3).MembershipFunctions(4).Parameters(2);
                end
            elseif app.nivelSombreamentoSlider.Visible == 1
                i8 = app.nivelSombreamentoSlider.Value;
            end

            i9=app.telemetriaSwitch.Value;

            i10=app.raspSwitch.Value;

            i11=app.wifiSwitch.Value;
                
            if app.redeMovelDropDown.Visible == 1
                if app.redeMovelDropDown.Value == "inexistente"
                    i12 = fistree.FIS(5).Inputs(2).MembershipFunctions(1).Parameters(2);
                elseif app.redeMovelDropDown.Value == "aceitável"
                    i12 = fistree.FIS(5).Inputs(2).MembershipFunctions(2).Parameters(2);
                elseif app.redeMovelDropDown.Value == "normal ou boa"
                    i12 = fistree.FIS(5).Inputs(2).MembershipFunctions(3).Parameters(2);
                end
            elseif app.redeMovelSlider.Visible == 1
                i12 = app.redeMovelSlider.Value;
            end

            if app.tempoMonitoramentoDropDown.Visible == 1
                if app.tempoMonitoramentoDropDown.Value == "curto"
                    i13 = fistree.FIS(7).Inputs(2).MembershipFunctions(1).Parameters(2);
                elseif app.tempoMonitoramentoDropDown.Value == "médio"
                    i13 = fistree.FIS(7).Inputs(2).MembershipFunctions(2).Parameters(2);
                elseif app.tempoMonitoramentoDropDown.Value == "longo"
                    i13 = fistree.FIS(7).Inputs(2).MembershipFunctions(3).Parameters(2);
                end
            elseif app.tempoMonitoramentoSlider.Visible == 1
                i13 = app.tempoMonitoramentoSlider.Value;
            end

            i14=app.preferenciaSwitch.Value; 
            
            if app.autonomiaDropDown.Visible == 1
                if app.autonomiaDropDown.Value == "mínima"
                    i15 = fistree.FIS(9).Inputs(1).MembershipFunctions(1).Parameters(2);
                elseif app.autonomiaDropDown.Value == "moderada"
                    i15 = fistree.FIS(9).Inputs(1).MembershipFunctions(2).Parameters(2);
                elseif app.autonomiaDropDown.Value == "estendida"
                    i15 = fistree.FIS(9).Inputs(1).MembershipFunctions(3).Parameters(2);
                end
            elseif app.autonomiaSlider.Visible == 1
                i15 = app.autonomiaSlider.Value;
            end

            i16=app.estacaoCarregamentoSwitch.Value;

            inputs=[i1 i2 i3 i4 i5 i6 i7 i8 i9 i10 i11 i12 i13 i14 i15 i16];
        end

        
        function varLinguistica = processamento_saidas(~,outputs)
            % As saídas da fistree sef.mat são dadas como entradas do arquivo resultados.mat
            inputs = outputs;

            fis = readfis('resultados.mat');

            % Avaliar o sistema fuzzy
            [~,fuzzifiedIn] = evalfis(fis.FIS(1), inputs);  % Retorna graus de pertinência

            defuzzifiedOut = fuzzifiedIn;

            len = length(inputs);

            outputMFs = {};
            outputMFs(1,:) = {defuzzifiedOut(1:3,1)};
            outputMFs(2,:) = {defuzzifiedOut(4:6,2)};
            outputMFs(3,:) = {defuzzifiedOut(7:9,3)};
            outputMFs(4,:) = {defuzzifiedOut(10:13,4)};
            outputMFs(5,:) = {defuzzifiedOut(14:16,5)};            
            outputMFs(6,:) = {defuzzifiedOut(17:19,6)};
            outputMFs(7,:) = {defuzzifiedOut(20:21,7)};
            outputMFs(8,:) = {defuzzifiedOut(22:23,8)};

            % Pré-alocação das variáveis
            outputMFNames = cell(len, 1);
            maxDegree = zeros(len, 1);
            maxIndex = zeros(len, 1);
            varLinguistica = strings(len, 1);

            for i = 1:len
                % Obter os nomes das funções de pertinência (variáveis linguísticas)
                outputMFNames(i,:) = {[fis.FIS(1).Inputs(i).MembershipFunctions.Name]};

                % Identificar a variável linguística com maior grau de pertinência
                [maxDegree(i), maxIndex(i)] = max(outputMFs{i,:});

                varLinguistica(i) = outputMFNames{i,:}(maxIndex(i));
            end

        end
        

        function resultados(app,varLinguistica,i4)
           
            app.obsLabel.Visible = 1;

            if i4 == 0 % câmera NÃO definida previamente
                switch varLinguistica(1)
                    case 'pequeno'
                        app.porteCameraLabel.Text='A câmera deve ser de porte pequeno, indicando um tamanho reduzido e baixo consumo de energia.';
                    case 'médio'
                        app.porteCameraLabel.Text='A câmera deve ser de porte médio, equilibrando tamanho e consumo. São exemplos: modelos comerciais convencionais da Série Pro (Hikvision) ou das Séries 1000/3000 (Intelbras).';
                    case 'grande'
                        app.porteCameraLabel.Text='A câmera deve ser de porte grande, garantindo maior alcance e recursos avançados. São exemplos: modelos mais robustos da Série Pro (Hikvision) ou das Séries 3000/5000 (Intelbras).';
                end
            else % câmera definida previamente
                switch varLinguistica(1)
                    case 'pequeno'
                        app.porteCameraLabel.Text= 'A câmera definida pelo usuário é de porte pequeno, indicando um baixo consumo de energia.';
                    case 'médio'
                        app.porteCameraLabel.Text= 'A câmera definida pelo usuário é de porte médio, indicando um consumo de energia moderado.';
                    case 'grande'
                        app.porteCameraLabel.Text= 'A câmera definida pelo usuário é de porte grande, indicando um modelo mais robusto, com alto consumo de energia.';
                end
            end

            if i4 == 0 % câmera NÃO definida previamente
                switch varLinguistica(2)
                    case 'compacta'
                        app.tipoCameraLabel.Text='Recomenda-se uma câmera compacta, priorizando discrição e o menor tamanho possível. Exemplos: módulos de câmera compatíveis com Raspberry Pi ou modelos da linha covert network da Hikvision.';
                    case 'bullet'
                        app.tipoCameraLabel.Text='Recomenda-se uma câmera IP do tipo bullet, ideal para monitorar pontos fixos.';
                    case 'speed dome'
                        app.tipoCameraLabel.Text='Recomenda-se uma câmera IP do tipo speed dome, que possui recursos PTZ (pan-tilt-zoom), garantindo maior versatilidade e cobertura da área monitorada.';                        
                end
            else % câmera definida previamente
                switch varLinguistica(2)
                    case 'compacta'
                        app.tipoCameraLabel.Text= 'Para fins de comparação, a câmera sugerida pelo programa é uma câmera compacta, como módulos de câmera compatíveis com Raspberry Pi ou modelos da linha covert network da Hikvision.';
                    case 'bullet'
                        app.tipoCameraLabel.Text= 'Para fins de comparação, a câmera sugerida pelo programa é uma câmera IP do tipo bullet.';
                    case 'speed dome'
                        app.tipoCameraLabel.Text= 'Para fins de comparação, a câmera sugerida pelo programa é uma câmera IP do tipo speed dome, que possui recursos PTZ (pan-tilt-zoom).';
                end
            end

            switch varLinguistica(3)
                case 'nada'
                    app.tipoTelemetriaLabel.Text= 'Não será implementado nenhum tipo de telemetria.';
                case 'esp32'
                    app.tipoTelemetriaLabel.Text= 'Opte por um ESP32, um microcontrolador de baixo custo e consumo que tem suporte para diversos tipos de sensores.';
                case 'raspberry pi'
                    app.tipoTelemetriaLabel.Text= 'Sugere-se o uso de um microcomputador Raspberry Pi para integrar o sisterma de telemetria, que possui acessórios e módulos adicionais mais avançados, se comparados ao ESP32.';                         
            end

            switch varLinguistica(4)
                case 'wifi'
                    app.tipoConexaoLabel.Text= 'Utilize a rede Wi-Fi disponível no local de instalação do sistema';
                case 'elsys'
                    app.tipoConexaoLabel.Text= 'Para áreas que possuem algum sinal de rede móvel, utilize um roteador externo integrado a uma antena. Um exemplo é a solução Amplimax Fit, da marca Elsys.';
                case 'starlink'
                    app.tipoConexaoLabel.Text= 'Como a área não possui nenhum sinal de rede móvel, opte pela solução Starlink, que consiste em um kit com uma fonte, um roteador e uma antena que possibilita a conexão à rede via satélite.';
                case 'módulo rasp'
                    app.tipoConexaoLabel.Text= 'Utilize um módulo 4G compatível com o Raspberry Pi. Esta é uma solução compacta e de baixo consumo, ideal em cenários que não requerem tamanha robustez da estrutura de acesso à rede.';                         
            end

            switch varLinguistica(5)
                case 'compacto'
                    app.tipoModuloLabel.Text= 'Para compor o arranjo fotovoltaico, recomenda-se a utilização de módulos compactos, painéis rígidos de tamanho e peso reduzidos, ideais para espaços limitados e instalações de baixa potência.';
                case 'flexível'
                    app.tipoModuloLabel.Text= 'Para compor o arranjo fotovoltaico, recomenda-se a utilização de módulos flexíveis, que, por não possuírem estrutura rígida, são mais leves e se adaptam melhor a superfícies irregulares e cenários em que há incertezas quanto ao tipo de estrutura de fixação dos módulos. Além disso, esse tipo possui variações de potência e de tamanho, permitindo certa versatilidade do sistema.';
                case 'convencional'
                    app.tipoModuloLabel.Text= 'Para compor o arranjo fotovoltaico, recomenda-se a utilização módulos convencionais, painéis rígidos apropriados para sistemas instalados em estruturas fixas e estáveis que demandam uma alta produção de energia.';                         
            end

            switch varLinguistica(6)
                case 'estação'
                    app.tipoBateriaLabel.Text= 'É possível utilizar uma estação de carregamento (power station), que une dispositivos como controlador de carga, inversor e banco de baterias em um único equipamento. Exemplos de marcas que trabalham com este tipo de tecnologia: Bluetti, Allpowers ou Jackery.';
                case 'célula'
                    app.tipoBateriaLabel.Text= 'Para o armazenamento de energia, sugere-se utilizar células de lítio, que são compactas e podem ser associadas entre si para aumentar a capacidade de armazenamento, a corrente e/ou a tensão do sistema.';
                case 'convencional'
                    app.tipoBateriaLabel.Text= 'Para o armazenamento de energia, sugere-se utilizar baterias de lítio convencionais, que oferecem uma maior capacidade de armazenamento individualmente e, caso necessário, podem ser associadas entre si para para aprimorar a capacidade de armazenamento, a corrente e/ou a tensão do sistema.';                       
            end

            switch varLinguistica(7)
                case 'não'
                    app.controladorLabel.Text= 'Não é necessário incluir um controlador de carga no sistema.';
                case 'sim'
                    app.controladorLabel.Text= 'É necessário incluir um controlador de carga para maximizar a eficiência do arranjo fotovoltaico.';                      
            end

            switch varLinguistica(8)
                case 'não'
                    app.inversorLabel.Text= 'Não é necessário incluir um inversor no sistema.';
                case 'sim'
                    app.inversorLabel.Text= 'É necessário incluir um inversor, dado que o sistema possui cargas que operam em corrente alternada (CA).';                      
            end
        end
        
    end
    

    % Callbacks that handle component events
    methods (Access = private)

        % Button pushed function: executarButton
        function executarButtonPushed(app, event)
            fistree = readfis('sef.mat');
             
            % Função que retorna um vetor com todas as entradas
            inputs = app.leitura_entradas(fistree);

            % Comando evalfis para processar a fistree e obter as saídas
            outputs = evalfis(fistree,inputs);

            % Processamento das saídas desfuzzyficadas
            varLinguistica = app.processamento_saidas(outputs);
            
            app.resultados(varLinguistica,inputs(4));         

            app.TabGroup.SelectedTab = app.ResultadosTab;
           
        end

        % Value changed function: definicaoPreviaSwitch
        function definicaoPreviaSwitchValueChanged(app, event)
            value = app.definicaoPreviaSwitch.Value;
            app.camDefinidaPanel.Visible = value;
            app.camDefinidaTooltip.Visible = value;
        end

        % Button pushed function: slider2dropButton_1
        function slider2dropButton_1Pushed(app, event)
            if app.distanciaSlider.Visible
                app.distanciaSlider.Visible = 0;
                app.distanciaDropDown.Visible = 1;
            else
                app.distanciaSlider.Visible = 1;
                app.distanciaDropDown.Visible = 0;
            end
        end

        % Button pushed function: slider2dropButton_2
        function slider2dropButton_2Pushed(app, event)
            if app.tempoMonitoramentoSlider.Visible
                app.tempoMonitoramentoSlider.Visible = 0;
                app.tempoMonitoramentoDropDown.Visible = 1;
            else
                app.tempoMonitoramentoSlider.Visible = 1;
                app.tempoMonitoramentoDropDown.Visible = 0;
            end
        end

        % Button pushed function: slider2dropButton_3
        function slider2dropButton_3Pushed(app, event)
            if app.camDefinidaSlider.Visible
                app.camDefinidaSlider.Visible = 0;
                app.camDefinidaDropDown.Visible = 1;
            else
                app.camDefinidaSlider.Visible = 1;
                app.camDefinidaDropDown.Visible = 0;
            end
        end

        % Button pushed function: slider2dropButton_4
        function slider2dropButton_4Pushed(app, event)
            if app.incidenciaSolarSlider.Visible
                app.incidenciaSolarSlider.Visible = 0;
                app.incidenciaSolarDropDown.Visible = 1;
            else
                app.incidenciaSolarSlider.Visible = 1;
                app.incidenciaSolarDropDown.Visible = 0;
            end
        end

        % Button pushed function: slider2dropButton_5
        function slider2dropButton_5Pushed(app, event)
            if app.nivelSombreamentoSlider.Visible
                app.nivelSombreamentoSlider.Visible = 0;
                app.nivelSombreamentoDropDown.Visible = 1;
            else
                app.nivelSombreamentoSlider.Visible = 1;
                app.nivelSombreamentoDropDown.Visible = 0;
            end
        end

        % Button pushed function: slider2dropButton_6
        function slider2dropButton_6Pushed(app, event)
            if app.redeMovelSlider.Visible
                app.redeMovelSlider.Visible = 0;
                app.redeMovelDropDown.Visible = 1;
            else
                app.redeMovelSlider.Visible = 1;
                app.redeMovelDropDown.Visible = 0;
            end
        end

        % Button pushed function: slider2dropButton_7
        function slider2dropButton_7Pushed(app, event)
            if app.autonomiaSlider.Visible
                app.autonomiaSlider.Visible = 0;
                app.autonomiaDropDown.Visible = 1;
            else
                app.autonomiaSlider.Visible = 1;
                app.autonomiaDropDown.Visible = 0;
            end
        end

        % Button pushed function: anteriorButton
        function anteriorButtonPushed(app, event)
            switch app.TabGroup.SelectedTab
                case app.IntroducaoTab
                
                case app.Parte1Tab
                    app.TabGroup.SelectedTab = app.IntroducaoTab;
                case app.Parte2Tab
                    app.TabGroup.SelectedTab = app.Parte1Tab;
                case app.Parte3Tab
                    app.TabGroup.SelectedTab = app.Parte2Tab;
                case app.ResultadosTab
                    app.TabGroup.SelectedTab = app.Parte3Tab;
                otherwise
            end
        end

        % Button pushed function: proximoButton
        function proximoButtonPushed(app, event)
            switch app.TabGroup.SelectedTab
                case app.IntroducaoTab
                    app.TabGroup.SelectedTab = app.Parte1Tab;
                case app.Parte1Tab
                    app.TabGroup.SelectedTab = app.Parte2Tab;
                case app.Parte2Tab
                    app.TabGroup.SelectedTab = app.Parte3Tab;
                case app.Parte3Tab
                    app.TabGroup.SelectedTab = app.ResultadosTab;
                case app.ResultadosTab

                otherwise

            end
        end

        % Button pushed function: salvarButton
        function salvarButtonPushed(app, event)
            app.TabGroup.SelectedTab = app.ResultadosTab;

            % Captura a tela da janela do aplicativo
            frame = getframe(app.UIFigure); % app.UIFigure é a janela principal do App Designer
            img = frame.cdata; % Extrai a imagem da captura
        
            % Define o nome do arquivo e o local para salvar
            filename = 'resultados.png'; % Nome do arquivo
            filepath = fullfile(pwd, filename); % Salva no diretório atual
        
            % Salva a imagem como um arquivo PNG
            imwrite(img, filepath);
        
            % Exibe uma mensagem para o usuário
            uialert(app.UIFigure, ['Captura de tela salva em: ' filepath], 'Captura Concluída');
        end
    end

    % Component initialization
    methods (Access = private)

        % Create UIFigure and components
        function createComponents(app)

            % Get the file path for locating images
            pathToMLAPP = fileparts(mfilename('fullpath'));

            % Create UIFigure and hide until all components are created
            app.UIFigure = uifigure('Visible', 'off');
            app.UIFigure.Color = [0.3882 0.5294 0.298];
            app.UIFigure.Position = [100 100 960 540];
            app.UIFigure.Name = 'MATLAB App';
            app.UIFigure.Resize = 'off';

            % Create TabGroup
            app.TabGroup = uitabgroup(app.UIFigure);
            app.TabGroup.Position = [14 14 751 513];

            % Create IntroducaoTab
            app.IntroducaoTab = uitab(app.TabGroup);
            app.IntroducaoTab.Title = 'Introdução';

            % Create GridLayout4
            app.GridLayout4 = uigridlayout(app.IntroducaoTab);
            app.GridLayout4.ColumnWidth = {'1x', '19x', '1x'};
            app.GridLayout4.RowHeight = {30, '1x', 24, 40, 20, 40, 20, 40, '1x', 15};
            app.GridLayout4.ColumnSpacing = 5;
            app.GridLayout4.RowSpacing = 5;

            % Create Label_1
            app.Label_1 = uilabel(app.GridLayout4);
            app.Label_1.VerticalAlignment = 'bottom';
            app.Label_1.FontName = 'Open Sans';
            app.Label_1.FontSize = 14;
            app.Label_1.FontWeight = 'bold';
            app.Label_1.Layout.Row = 1;
            app.Label_1.Layout.Column = 2;
            app.Label_1.Text = 'Sistema especialista fuzzy para soluções de monitoramento remoto off-grid';

            % Create Label_2
            app.Label_2 = uilabel(app.GridLayout4);
            app.Label_2.WordWrap = 'on';
            app.Label_2.FontName = 'Open Sans';
            app.Label_2.Layout.Row = 2;
            app.Label_2.Layout.Column = 2;
            app.Label_2.Text = {'Essa interface é parte integrante do sistema especialista baseado em regras fuzzy, que tem como objetivo indicar diferentes soluções de desenvolvimento e implementação de sistemas de monitoramento remoto para uso em programas de conservação ambiental. O escopo do projeto inclui o foco em soluções integradas ao uso de energia solar fotovoltaica isolada da rede (off-grid).'; 'Nessa interface, o usuário deve fornecer as informações relevantes para, ao final, obter uma recomendação adequada às particularidades de seu projeto.'};

            % Create Label_3
            app.Label_3 = uilabel(app.GridLayout4);
            app.Label_3.VerticalAlignment = 'bottom';
            app.Label_3.WordWrap = 'on';
            app.Label_3.FontName = 'Open Sans';
            app.Label_3.FontSize = 14;
            app.Label_3.FontWeight = 'bold';
            app.Label_3.Layout.Row = 3;
            app.Label_3.Layout.Column = 2;
            app.Label_3.Text = 'Como usar o programa?';

            % Create Label_4
            app.Label_4 = uilabel(app.GridLayout4);
            app.Label_4.WordWrap = 'on';
            app.Label_4.FontName = 'Open Sans';
            app.Label_4.Layout.Row = 4;
            app.Label_4.Layout.Column = 2;
            app.Label_4.Text = '1. Navegue pelas abas disponíveis e responda às perguntas relacionadas ao seu projeto. É preciso ter ao menos uma noção do que se pretende monitorar e de características da região onde o sistema será instalado.';

            % Create Label_5
            app.Label_5 = uilabel(app.GridLayout4);
            app.Label_5.WordWrap = 'on';
            app.Label_5.FontName = 'Open Sans';
            app.Label_5.Layout.Row = 5;
            app.Label_5.Layout.Column = 2;
            app.Label_5.Text = '2. Após preencher todas as informações, clique no botão EXECUTAR.';

            % Create Label_6
            app.Label_6 = uilabel(app.GridLayout4);
            app.Label_6.WordWrap = 'on';
            app.Label_6.FontName = 'Open Sans';
            app.Label_6.Layout.Row = 6;
            app.Label_6.Layout.Column = 2;
            app.Label_6.Text = '3. Na aba Resultados, você encontrará um conjunto de recomendações geradas com base nas variáveis de entrada fornecidas.';

            % Create Label_7
            app.Label_7 = uilabel(app.GridLayout4);
            app.Label_7.WordWrap = 'on';
            app.Label_7.FontName = 'Open Sans';
            app.Label_7.Layout.Row = 7;
            app.Label_7.Layout.Column = 2;
            app.Label_7.Text = '4. Ao finalizar, você pode salvar uma captura da tela com as recomendações ao clicar em SALVAR RESULTADOS.';

            % Create Label_8
            app.Label_8 = uilabel(app.GridLayout4);
            app.Label_8.WordWrap = 'on';
            app.Label_8.FontName = 'Open Sans';
            app.Label_8.Layout.Row = 8;
            app.Label_8.Layout.Column = 2;
            app.Label_8.Text = 'O objetivo é garantir que as soluções sejam adaptadas às suas necessidades específicas, mas dentro de um escopo limitado de opções viáveis tecnicamente.';

            % Create Label_9
            app.Label_9 = uilabel(app.GridLayout4);
            app.Label_9.WordWrap = 'on';
            app.Label_9.FontName = 'Open Sans';
            app.Label_9.Layout.Row = 9;
            app.Label_9.Layout.Column = 2;
            app.Label_9.Text = {'Todos os arquivos e códigos desenvolvidos são parte do projeto de graduação da estudante Ana Carolina Calenzani Marinho, e estão disponíveis no repositório da autora, permitindo que outros desenvolvedores e pesquisadores possam aprimorar ou adaptar a ferramenta para novas aplicações.'; ''; 'TÍTULO: SISTEMA ESPECIALISTA FUZZY PARA SOLUÇÕES BASEADAS EM ENERGIA SOLAR FOTOVOLTAICA PARA MONITORAMENTO REMOTO DE ESPÉCIES '};

            % Create Hyperlink
            app.Hyperlink = uihyperlink(app.GridLayout4);
            app.Hyperlink.VerticalAlignment = 'bottom';
            app.Hyperlink.FontName = 'Open Sans';
            app.Hyperlink.FontSize = 11;
            app.Hyperlink.Layout.Row = 10;
            app.Hyperlink.Layout.Column = 2;
            app.Hyperlink.URL = 'https://github.com/anacalenzani/sistema-especialista-fuzzy';
            app.Hyperlink.Text = 'Clique aqui para acessar o repositório';

            % Create Parte1Tab
            app.Parte1Tab = uitab(app.TabGroup);
            app.Parte1Tab.Title = 'Parte 1';

            % Create GridLayout
            app.GridLayout = uigridlayout(app.Parte1Tab);
            app.GridLayout.ColumnWidth = {37, '7x', 20, '2x', '7x', 20, '1x'};
            app.GridLayout.RowHeight = {'1x', 20, '1.5x', '1x', 20, '1.5x', 12, 5, 12, 20, '1.5x', '1x'};
            app.GridLayout.ColumnSpacing = 5;
            app.GridLayout.RowSpacing = 5;

            % Create distanciaPanel
            app.distanciaPanel = uipanel(app.GridLayout);
            app.distanciaPanel.Title = 'Distância da câmera até o ponto monitorado (m)';
            app.distanciaPanel.Layout.Row = [2 3];
            app.distanciaPanel.Layout.Column = 2;
            app.distanciaPanel.FontName = 'open sans';
            app.distanciaPanel.FontSize = 10.8;

            % Create slider2dropButton_1
            app.slider2dropButton_1 = uibutton(app.distanciaPanel, 'push');
            app.slider2dropButton_1.ButtonPushedFcn = createCallbackFcn(app, @slider2dropButton_1Pushed, true);
            app.slider2dropButton_1.VerticalAlignment = 'top';
            app.slider2dropButton_1.FontName = 'Liberation Sans';
            app.slider2dropButton_1.FontWeight = 'bold';
            app.slider2dropButton_1.Position = [8 28 20 20];
            app.slider2dropButton_1.Text = '';
            app.slider2dropButton_1.Icon = fullfile(pathToMLAPP, 'troca.png');

            % Create distanciaSlider
            app.distanciaSlider = uislider(app.distanciaPanel);
            app.distanciaSlider.Limits = [0 60];
            app.distanciaSlider.MajorTicks = [0 10 20 30 40 50 60 70 80 90 100];
            app.distanciaSlider.FontSize = 10;
            app.distanciaSlider.Position = [44 46 180 3];

            % Create distanciaDropDown
            app.distanciaDropDown = uidropdown(app.distanciaPanel);
            app.distanciaDropDown.Items = {'curta', 'média', 'longa'};
            app.distanciaDropDown.Visible = 'off';
            app.distanciaDropDown.Position = [45 27 180 22];
            app.distanciaDropDown.Value = 'curta';

            % Create distanciaTooltip
            app.distanciaTooltip = uilabel(app.GridLayout);
            app.distanciaTooltip.BackgroundColor = [0 0.4471 0.7412];
            app.distanciaTooltip.HorizontalAlignment = 'center';
            app.distanciaTooltip.FontWeight = 'bold';
            app.distanciaTooltip.FontColor = [1 1 1];
            app.distanciaTooltip.Tooltip = {'A distância entre a câmera e o ponto a ser monitorado deve ser levada em consideração para determinar adequadamente o porte da câmera.'};
            app.distanciaTooltip.Layout.Row = 2;
            app.distanciaTooltip.Layout.Column = 3;
            app.distanciaTooltip.Text = '?';

            % Create tempoMonitoramentoPanel
            app.tempoMonitoramentoPanel = uipanel(app.GridLayout);
            app.tempoMonitoramentoPanel.Title = 'Tempo de monitoramento diário (h)';
            app.tempoMonitoramentoPanel.Layout.Row = [5 6];
            app.tempoMonitoramentoPanel.Layout.Column = 2;
            app.tempoMonitoramentoPanel.FontName = 'Open Sans';

            % Create slider2dropButton_2
            app.slider2dropButton_2 = uibutton(app.tempoMonitoramentoPanel, 'push');
            app.slider2dropButton_2.ButtonPushedFcn = createCallbackFcn(app, @slider2dropButton_2Pushed, true);
            app.slider2dropButton_2.VerticalAlignment = 'top';
            app.slider2dropButton_2.FontName = 'Liberation Sans';
            app.slider2dropButton_2.FontWeight = 'bold';
            app.slider2dropButton_2.Position = [8 27 20 20];
            app.slider2dropButton_2.Text = '';
            app.slider2dropButton_2.Icon = fullfile(pathToMLAPP, 'troca.png');

            % Create tempoMonitoramentoSlider
            app.tempoMonitoramentoSlider = uislider(app.tempoMonitoramentoPanel);
            app.tempoMonitoramentoSlider.Limits = [0 24];
            app.tempoMonitoramentoSlider.MajorTicks = [0 4 8 12 16 20 24];
            app.tempoMonitoramentoSlider.MinorTicks = [0 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24];
            app.tempoMonitoramentoSlider.Position = [44 47 180 3];

            % Create tempoMonitoramentoDropDown
            app.tempoMonitoramentoDropDown = uidropdown(app.tempoMonitoramentoPanel);
            app.tempoMonitoramentoDropDown.Items = {'curto', 'médio', 'longo'};
            app.tempoMonitoramentoDropDown.Visible = 'off';
            app.tempoMonitoramentoDropDown.Position = [45 26 181 22];
            app.tempoMonitoramentoDropDown.Value = 'curto';

            % Create tempoMonitoramentoTooltip
            app.tempoMonitoramentoTooltip = uilabel(app.GridLayout);
            app.tempoMonitoramentoTooltip.BackgroundColor = [0 0.4471 0.7412];
            app.tempoMonitoramentoTooltip.HorizontalAlignment = 'center';
            app.tempoMonitoramentoTooltip.FontWeight = 'bold';
            app.tempoMonitoramentoTooltip.FontColor = [1 1 1];
            app.tempoMonitoramentoTooltip.Tooltip = {'Tempo de operação desejado para a câmera durante um dia. Essa informação influencia no consumo de energia elétrica do sistema.'};
            app.tempoMonitoramentoTooltip.Layout.Row = 5;
            app.tempoMonitoramentoTooltip.Layout.Column = 3;
            app.tempoMonitoramentoTooltip.Text = '?';

            % Create definicaoPreviaPanel
            app.definicaoPreviaPanel = uipanel(app.GridLayout);
            app.definicaoPreviaPanel.Layout.Row = [10 11];
            app.definicaoPreviaPanel.Layout.Column = 2;

            % Create definicaoPreviaLabel
            app.definicaoPreviaLabel = uilabel(app.definicaoPreviaPanel);
            app.definicaoPreviaLabel.WordWrap = 'on';
            app.definicaoPreviaLabel.FontName = 'Open Sans';
            app.definicaoPreviaLabel.Position = [5 48 246 33];
            app.definicaoPreviaLabel.Text = 'Você possui um modelo de câmera definido previamente?';

            % Create definicaoPreviaSwitch
            app.definicaoPreviaSwitch = uiswitch(app.definicaoPreviaPanel, 'slider');
            app.definicaoPreviaSwitch.Items = {'Não', 'Sim'};
            app.definicaoPreviaSwitch.ItemsData = [0 1];
            app.definicaoPreviaSwitch.ValueChangedFcn = createCallbackFcn(app, @definicaoPreviaSwitchValueChanged, true);
            app.definicaoPreviaSwitch.Position = [107 17 45 20];
            app.definicaoPreviaSwitch.Value = 0;

            % Create definicaoPreviaTooltip
            app.definicaoPreviaTooltip = uilabel(app.GridLayout);
            app.definicaoPreviaTooltip.BackgroundColor = [0 0.4471 0.7412];
            app.definicaoPreviaTooltip.HorizontalAlignment = 'center';
            app.definicaoPreviaTooltip.FontWeight = 'bold';
            app.definicaoPreviaTooltip.FontColor = [1 1 1];
            app.definicaoPreviaTooltip.Tooltip = {'Caso o usuário já possua um modelo de câmera a ser utilizado, o programa sugere os componentes do sistema com base no porte do modelo definido.'};
            app.definicaoPreviaTooltip.Layout.Row = 10;
            app.definicaoPreviaTooltip.Layout.Column = 3;
            app.definicaoPreviaTooltip.Text = '?';

            % Create recursosPTZPanel
            app.recursosPTZPanel = uipanel(app.GridLayout);
            app.recursosPTZPanel.Layout.Row = [2 3];
            app.recursosPTZPanel.Layout.Column = 5;

            % Create recursosPTZLabel
            app.recursosPTZLabel = uilabel(app.recursosPTZPanel);
            app.recursosPTZLabel.WordWrap = 'on';
            app.recursosPTZLabel.FontName = 'Open Sans';
            app.recursosPTZLabel.Position = [6 53 244 29];
            app.recursosPTZLabel.Text = 'É necessário que a câmera possua recursos PTZ (pan-tilt-zoom)?';

            % Create recursosPTZSwitch
            app.recursosPTZSwitch = uiswitch(app.recursosPTZPanel, 'slider');
            app.recursosPTZSwitch.Items = {'Não', 'Sim'};
            app.recursosPTZSwitch.ItemsData = [0 1];
            app.recursosPTZSwitch.Position = [108 16 45 20];
            app.recursosPTZSwitch.Value = 0;

            % Create recursosPTZTooltip
            app.recursosPTZTooltip = uilabel(app.GridLayout);
            app.recursosPTZTooltip.BackgroundColor = [0 0.4471 0.7412];
            app.recursosPTZTooltip.HorizontalAlignment = 'center';
            app.recursosPTZTooltip.FontWeight = 'bold';
            app.recursosPTZTooltip.FontColor = [1 1 1];
            app.recursosPTZTooltip.Tooltip = {'PTZ: pan-tilt-zoom, permitindo movimentos no eixo horizontal, vertical e zoom.'; 'Alguns modelos de câmera tem o ponto de visão fixo (bullet), podendo ter seu ângulo ajustado apenas manualmente. Enquanto outros modelos (speed dome) permitem movimentação da câmera de maneira remota.'};
            app.recursosPTZTooltip.Layout.Row = 2;
            app.recursosPTZTooltip.Layout.Column = 6;
            app.recursosPTZTooltip.Text = '?';

            % Create tamanhoPanel
            app.tamanhoPanel = uipanel(app.GridLayout);
            app.tamanhoPanel.Layout.Row = [5 6];
            app.tamanhoPanel.Layout.Column = 5;

            % Create tamanhoLabel
            app.tamanhoLabel = uilabel(app.tamanhoPanel);
            app.tamanhoLabel.WordWrap = 'on';
            app.tamanhoLabel.FontName = 'Open Sans';
            app.tamanhoLabel.Position = [9 42 241 43];
            app.tamanhoLabel.Text = 'O tamanho e a discrição da câmera devem ser as maiores prioridade do sistema?';

            % Create tamanhoSwitch
            app.tamanhoSwitch = uiswitch(app.tamanhoPanel, 'slider');
            app.tamanhoSwitch.Items = {'Não', 'Sim'};
            app.tamanhoSwitch.ItemsData = [0 1];
            app.tamanhoSwitch.Position = [108 15 45 20];
            app.tamanhoSwitch.Value = 0;

            % Create tamanhoTooltip
            app.tamanhoTooltip = uilabel(app.GridLayout);
            app.tamanhoTooltip.BackgroundColor = [0 0.4471 0.7412];
            app.tamanhoTooltip.HorizontalAlignment = 'center';
            app.tamanhoTooltip.FontWeight = 'bold';
            app.tamanhoTooltip.FontColor = [1 1 1];
            app.tamanhoTooltip.Tooltip = {'Essa informação é crucial para determinar se o programa deve sugerir modelos convencionais, que priorizam a qualidade das imagens capturadas, ou se é mais importante optar por câmeras discretas e compactas, mesmo que isso implique uma redução na qualidade das imagens. A escolha dependerá das necessidades específicas do cenário de monitoramento.'};
            app.tamanhoTooltip.Layout.Row = 5;
            app.tamanhoTooltip.Layout.Column = 6;
            app.tamanhoTooltip.Text = '?';

            % Create camDefinidaPanel
            app.camDefinidaPanel = uipanel(app.GridLayout);
            app.camDefinidaPanel.Visible = 'off';
            app.camDefinidaPanel.Layout.Row = [10 11];
            app.camDefinidaPanel.Layout.Column = 5;

            % Create camDefinidaLabel
            app.camDefinidaLabel = uilabel(app.camDefinidaPanel);
            app.camDefinidaLabel.WordWrap = 'on';
            app.camDefinidaLabel.FontName = 'Open Sans';
            app.camDefinidaLabel.FontSize = 11.8;
            app.camDefinidaLabel.Position = [6 53 248 29];
            app.camDefinidaLabel.Text = 'Qual é a estimativa de potência de operação (em W) deste modelo?';

            % Create slider2dropButton_3
            app.slider2dropButton_3 = uibutton(app.camDefinidaPanel, 'push');
            app.slider2dropButton_3.ButtonPushedFcn = createCallbackFcn(app, @slider2dropButton_3Pushed, true);
            app.slider2dropButton_3.VerticalAlignment = 'top';
            app.slider2dropButton_3.FontName = 'Liberation Sans';
            app.slider2dropButton_3.FontWeight = 'bold';
            app.slider2dropButton_3.Position = [11 17 20 20];
            app.slider2dropButton_3.Text = '';
            app.slider2dropButton_3.Icon = fullfile(pathToMLAPP, 'troca.png');

            % Create camDefinidaDropDown
            app.camDefinidaDropDown = uidropdown(app.camDefinidaPanel);
            app.camDefinidaDropDown.Items = {'baixa', 'média', 'alta'};
            app.camDefinidaDropDown.Visible = 'off';
            app.camDefinidaDropDown.Position = [48 15 180 24];
            app.camDefinidaDropDown.Value = 'baixa';

            % Create camDefinidaSlider
            app.camDefinidaSlider = uislider(app.camDefinidaPanel);
            app.camDefinidaSlider.Limits = [0 40];
            app.camDefinidaSlider.MajorTicks = [0 5 10 15 20 25 30 35 40];
            app.camDefinidaSlider.Position = [48 35 180 3];

            % Create camDefinidaTooltip
            app.camDefinidaTooltip = uilabel(app.GridLayout);
            app.camDefinidaTooltip.BackgroundColor = [0 0.4471 0.7412];
            app.camDefinidaTooltip.HorizontalAlignment = 'center';
            app.camDefinidaTooltip.FontWeight = 'bold';
            app.camDefinidaTooltip.FontColor = [1 1 1];
            app.camDefinidaTooltip.Visible = 'off';
            app.camDefinidaTooltip.Tooltip = {'Conhecer a potência de operação da câmera definida pelo usuário auxilia na estimativa do consumo de energia elétrica do sistema. '};
            app.camDefinidaTooltip.Layout.Row = 10;
            app.camDefinidaTooltip.Layout.Column = 6;
            app.camDefinidaTooltip.Text = '?';

            % Create divisoriaLabel_1
            app.divisoriaLabel_1 = uilabel(app.GridLayout);
            app.divisoriaLabel_1.BackgroundColor = [0.902 0.902 0.902];
            app.divisoriaLabel_1.Layout.Row = 8;
            app.divisoriaLabel_1.Layout.Column = [1 7];
            app.divisoriaLabel_1.Text = '';

            % Create Parte2Tab
            app.Parte2Tab = uitab(app.TabGroup);
            app.Parte2Tab.Title = 'Parte 2';

            % Create GridLayout_2
            app.GridLayout_2 = uigridlayout(app.Parte2Tab);
            app.GridLayout_2.ColumnWidth = {'1x', '7x', 20, 15, 5, '0.5x', 20, '7x', 20, '1x'};
            app.GridLayout_2.RowHeight = {'1x', 20, '1.5x', '1x', 20, '1.5x', '1x', 20, '1.5x', '1x'};
            app.GridLayout_2.ColumnSpacing = 5;
            app.GridLayout_2.RowSpacing = 5;

            % Create incidenciaSolarPanel
            app.incidenciaSolarPanel = uipanel(app.GridLayout_2);
            app.incidenciaSolarPanel.Title = 'Tempo de incidência solar diária (h)';
            app.incidenciaSolarPanel.Layout.Row = [5 6];
            app.incidenciaSolarPanel.Layout.Column = 2;
            app.incidenciaSolarPanel.FontName = 'Open Sans';

            % Create slider2dropButton_4
            app.slider2dropButton_4 = uibutton(app.incidenciaSolarPanel, 'push');
            app.slider2dropButton_4.ButtonPushedFcn = createCallbackFcn(app, @slider2dropButton_4Pushed, true);
            app.slider2dropButton_4.VerticalAlignment = 'top';
            app.slider2dropButton_4.FontName = 'Liberation Sans';
            app.slider2dropButton_4.FontWeight = 'bold';
            app.slider2dropButton_4.Position = [8 24 20 20];
            app.slider2dropButton_4.Text = '';
            app.slider2dropButton_4.Icon = fullfile(pathToMLAPP, 'troca.png');

            % Create incidenciaSolarDropDown
            app.incidenciaSolarDropDown = uidropdown(app.incidenciaSolarPanel);
            app.incidenciaSolarDropDown.Items = {'muito curto', 'curto', 'médio', 'longo'};
            app.incidenciaSolarDropDown.Visible = 'off';
            app.incidenciaSolarDropDown.Position = [45 24 181 21];
            app.incidenciaSolarDropDown.Value = 'muito curto';

            % Create incidenciaSolarSlider
            app.incidenciaSolarSlider = uislider(app.incidenciaSolarPanel);
            app.incidenciaSolarSlider.Limits = [0 14];
            app.incidenciaSolarSlider.MajorTicks = [0 2 4 6 8 10 12 14];
            app.incidenciaSolarSlider.MinorTicks = [0 1 2 3 4 5 6 7 8 9 10 11 12 13 14];
            app.incidenciaSolarSlider.Position = [44 43 180 3];

            % Create incidenciaSolarTooltip
            app.incidenciaSolarTooltip = uilabel(app.GridLayout_2);
            app.incidenciaSolarTooltip.BackgroundColor = [0 0.4471 0.7412];
            app.incidenciaSolarTooltip.HorizontalAlignment = 'center';
            app.incidenciaSolarTooltip.FontWeight = 'bold';
            app.incidenciaSolarTooltip.FontColor = [1 1 1];
            app.incidenciaSolarTooltip.Tooltip = {'Considere o tempo médio de incidência solar como as horas do dia em que os módulos fotovoltaicos estão recebendo alguma quantidade de luz ou radiação solar, ou seja, estão gerando energia, independentemente do nível de sombreamento sobre eles, desde que não estejam totalmente cobertos.'; 'Essa informação auxilia na seleção de equipamentos adequados para o sistema fotovoltaico.'};
            app.incidenciaSolarTooltip.Layout.Row = 5;
            app.incidenciaSolarTooltip.Layout.Column = 3;
            app.incidenciaSolarTooltip.Text = '?';

            % Create nivelSombreamentoPanel
            app.nivelSombreamentoPanel = uipanel(app.GridLayout_2);
            app.nivelSombreamentoPanel.Title = 'Nível de sombreamento (%)';
            app.nivelSombreamentoPanel.Layout.Row = [8 9];
            app.nivelSombreamentoPanel.Layout.Column = 2;
            app.nivelSombreamentoPanel.FontName = 'Open Sans';

            % Create slider2dropButton_5
            app.slider2dropButton_5 = uibutton(app.nivelSombreamentoPanel, 'push');
            app.slider2dropButton_5.ButtonPushedFcn = createCallbackFcn(app, @slider2dropButton_5Pushed, true);
            app.slider2dropButton_5.VerticalAlignment = 'top';
            app.slider2dropButton_5.FontName = 'Liberation Sans';
            app.slider2dropButton_5.FontWeight = 'bold';
            app.slider2dropButton_5.Position = [8 26 20 20];
            app.slider2dropButton_5.Text = '';
            app.slider2dropButton_5.Icon = fullfile(pathToMLAPP, 'troca.png');

            % Create nivelSombreamentoDropDown
            app.nivelSombreamentoDropDown = uidropdown(app.nivelSombreamentoPanel);
            app.nivelSombreamentoDropDown.Items = {'muito baixo', 'baixo', 'médio', 'alto'};
            app.nivelSombreamentoDropDown.Visible = 'off';
            app.nivelSombreamentoDropDown.Position = [45 25 181 21];
            app.nivelSombreamentoDropDown.Value = 'muito baixo';

            % Create nivelSombreamentoSlider
            app.nivelSombreamentoSlider = uislider(app.nivelSombreamentoPanel);
            app.nivelSombreamentoSlider.Position = [46 45 180 3];

            % Create nivelSombreamentoTooltip
            app.nivelSombreamentoTooltip = uilabel(app.GridLayout_2);
            app.nivelSombreamentoTooltip.BackgroundColor = [0 0.4471 0.7412];
            app.nivelSombreamentoTooltip.HorizontalAlignment = 'center';
            app.nivelSombreamentoTooltip.FontWeight = 'bold';
            app.nivelSombreamentoTooltip.FontColor = [1 1 1];
            app.nivelSombreamentoTooltip.Tooltip = {'Considerando os períodos em que há incidência solar sobre os módulos, indique o nível esperado de sombreamento sobre essa superfície ao longo do dia.'; 'Considere que:'; '- 0%: enquanto houver luz solar, não há sombras sobre o módulo.'; '- 50%: o painel teve metade de sua superfície coberta parcialmente durante o dia. '; '- 80%: a maior parte da superfície do painel solar ficou coberta ao longo do dia.'};
            app.nivelSombreamentoTooltip.Layout.Row = 8;
            app.nivelSombreamentoTooltip.Layout.Column = 3;
            app.nivelSombreamentoTooltip.Text = '?';

            % Create wifiPanel
            app.wifiPanel = uipanel(app.GridLayout_2);
            app.wifiPanel.Layout.Row = [2 3];
            app.wifiPanel.Layout.Column = 8;

            % Create wifiSwitch
            app.wifiSwitch = uiswitch(app.wifiPanel, 'slider');
            app.wifiSwitch.Items = {'Não', 'Sim'};
            app.wifiSwitch.ItemsData = [0 1];
            app.wifiSwitch.Position = [102 15 45 20];
            app.wifiSwitch.Value = 0;

            % Create wifiLabel
            app.wifiLabel = uilabel(app.wifiPanel);
            app.wifiLabel.WordWrap = 'on';
            app.wifiLabel.FontName = 'Open Sans';
            app.wifiLabel.Position = [7 50 245 30];
            app.wifiLabel.Text = 'Existe alguma rede Wi-Fi no local que possa ser utilizada?';

            % Create wifiTooltip
            app.wifiTooltip = uilabel(app.GridLayout_2);
            app.wifiTooltip.BackgroundColor = [0 0.4471 0.7412];
            app.wifiTooltip.HorizontalAlignment = 'center';
            app.wifiTooltip.FontWeight = 'bold';
            app.wifiTooltip.FontColor = [1 1 1];
            app.wifiTooltip.Tooltip = {'Caso já exista uma rede Wi-Fi que possa ser utilizada, não será necessário adquirir outros equipamentos relacionados ao acesso à rede para transmissão das imagens da câmera para o usuário.'};
            app.wifiTooltip.Layout.Row = 2;
            app.wifiTooltip.Layout.Column = 9;
            app.wifiTooltip.Text = '?';

            % Create preferenciaPanel
            app.preferenciaPanel = uipanel(app.GridLayout_2);
            app.preferenciaPanel.Layout.Row = [8 9];
            app.preferenciaPanel.Layout.Column = 8;

            % Create preferenciaLabel
            app.preferenciaLabel = uilabel(app.preferenciaPanel);
            app.preferenciaLabel.WordWrap = 'on';
            app.preferenciaLabel.FontName = 'Open Sans';
            app.preferenciaLabel.FontSize = 11.5;
            app.preferenciaLabel.Position = [5 49 247 28];
            app.preferenciaLabel.Text = 'A seleção do tipo de módulo fotovoltaico deve priorizar fatores como peso e flexibilidade?';

            % Create preferenciaSwitch
            app.preferenciaSwitch = uiswitch(app.preferenciaPanel, 'slider');
            app.preferenciaSwitch.Items = {'Não', 'Sim'};
            app.preferenciaSwitch.ItemsData = [0 1];
            app.preferenciaSwitch.Position = [102 13 45 20];
            app.preferenciaSwitch.Value = 0;

            % Create preferenciaTooltip
            app.preferenciaTooltip = uilabel(app.GridLayout_2);
            app.preferenciaTooltip.BackgroundColor = [0 0.4471 0.7412];
            app.preferenciaTooltip.HorizontalAlignment = 'center';
            app.preferenciaTooltip.FontWeight = 'bold';
            app.preferenciaTooltip.FontColor = [1 1 1];
            app.preferenciaTooltip.Tooltip = {'Ao priorizar esses fatores, o programa opta por painéis flexíveis, que podem ser instalados de diferentes formas nas árvores ou em outras estruturas com restrições de carga, devido a seu peso reduzido, que também facilita o transporte desse tipo de equipamento. No entanto, essa opção pode resultar em menor eficiência, potência e durabilidade, se comparada aos painéis convencionais. Avalie se as vantagens de adaptabilidade e leveza justificam as possíveis perdas de desempenho, conforme as necessidades do projeto.'};
            app.preferenciaTooltip.Layout.Row = 8;
            app.preferenciaTooltip.Layout.Column = 9;
            app.preferenciaTooltip.Text = '?';

            % Create redeMovelPanel
            app.redeMovelPanel = uipanel(app.GridLayout_2);
            app.redeMovelPanel.AutoResizeChildren = 'off';
            app.redeMovelPanel.Layout.Row = [5 6];
            app.redeMovelPanel.Layout.Column = 8;

            % Create redeMovelLabel
            app.redeMovelLabel = uilabel(app.redeMovelPanel);
            app.redeMovelLabel.WordWrap = 'on';
            app.redeMovelLabel.FontName = 'Open Sans';
            app.redeMovelLabel.Position = [17 53 226 30];
            app.redeMovelLabel.Text = 'Classifique a qualidade do sinal de rede móvel (3G, 4G ou 5G) no local.';

            % Create slider2dropButton_6
            app.slider2dropButton_6 = uibutton(app.redeMovelPanel, 'push');
            app.slider2dropButton_6.ButtonPushedFcn = createCallbackFcn(app, @slider2dropButton_6Pushed, true);
            app.slider2dropButton_6.VerticalAlignment = 'top';
            app.slider2dropButton_6.FontName = 'Liberation Sans';
            app.slider2dropButton_6.FontWeight = 'bold';
            app.slider2dropButton_6.Position = [10 18 20 20];
            app.slider2dropButton_6.Text = '';
            app.slider2dropButton_6.Icon = fullfile(pathToMLAPP, 'troca.png');

            % Create redeMovelDropDown
            app.redeMovelDropDown = uidropdown(app.redeMovelPanel);
            app.redeMovelDropDown.Items = {'inexistente', 'aceitável', 'normal ou boa'};
            app.redeMovelDropDown.Visible = 'off';
            app.redeMovelDropDown.Position = [47 17 181 21];
            app.redeMovelDropDown.Value = 'inexistente';

            % Create redeMovelSlider
            app.redeMovelSlider = uislider(app.redeMovelPanel);
            app.redeMovelSlider.Limits = [0 10];
            app.redeMovelSlider.MajorTicks = [0 1 2 3 4 5 6 7 8 9 10];
            app.redeMovelSlider.FontSize = 11;
            app.redeMovelSlider.Position = [46 37 180 3];

            % Create redeMovelTooltip
            app.redeMovelTooltip = uilabel(app.GridLayout_2);
            app.redeMovelTooltip.BackgroundColor = [0 0.4471 0.7412];
            app.redeMovelTooltip.HorizontalAlignment = 'center';
            app.redeMovelTooltip.FontWeight = 'bold';
            app.redeMovelTooltip.FontColor = [1 1 1];
            app.redeMovelTooltip.Tooltip = {'Para transmitir as imagens da câmera de maneira remota, é necessário entender a qualidade do sinal de rede móvel, a fim de determinar o equipamento mais adequado para viabilizar a comunicação remota entre sistema e usuário.'};
            app.redeMovelTooltip.Layout.Row = 5;
            app.redeMovelTooltip.Layout.Column = 9;
            app.redeMovelTooltip.Text = '?';

            % Create biomaPanel
            app.biomaPanel = uipanel(app.GridLayout_2);
            app.biomaPanel.Layout.Row = [2 3];
            app.biomaPanel.Layout.Column = 2;

            % Create biomaLabel
            app.biomaLabel = uilabel(app.biomaPanel);
            app.biomaLabel.FontName = 'Open Sans';
            app.biomaLabel.Position = [13 44 239 44];
            app.biomaLabel.Text = 'O sistema será instalado em qual bioma?';

            % Create biomaDropDown
            app.biomaDropDown = uidropdown(app.biomaPanel);
            app.biomaDropDown.Items = {'Amazônia', 'Mata Atlântica', 'Pantanal', 'Pampa', 'Cerrado', 'Caatinga'};
            app.biomaDropDown.Position = [70 15 121 25];
            app.biomaDropDown.Value = 'Amazônia';

            % Create biomaTooltip
            app.biomaTooltip = uilabel(app.GridLayout_2);
            app.biomaTooltip.BackgroundColor = [0 0.4471 0.7412];
            app.biomaTooltip.HorizontalAlignment = 'center';
            app.biomaTooltip.FontWeight = 'bold';
            app.biomaTooltip.FontColor = [1 1 1];
            app.biomaTooltip.Tooltip = {'O bioma pode fornecer informações como a densidade de vegetação do local de instalação e, em alguns casos, uma estimativa de localização geográfica, a fim de entender as faixas de valores de irradiação solar que essa área pode receber.'};
            app.biomaTooltip.Layout.Row = 2;
            app.biomaTooltip.Layout.Column = 3;
            app.biomaTooltip.Text = '?';

            % Create divisoriaLabel_2
            app.divisoriaLabel_2 = uilabel(app.GridLayout_2);
            app.divisoriaLabel_2.BackgroundColor = [0.902 0.902 0.902];
            app.divisoriaLabel_2.Layout.Row = [1 10];
            app.divisoriaLabel_2.Layout.Column = 5;
            app.divisoriaLabel_2.Text = '';

            % Create Parte3Tab
            app.Parte3Tab = uitab(app.TabGroup);
            app.Parte3Tab.Title = 'Parte 3';

            % Create GridLayout2
            app.GridLayout2 = uigridlayout(app.Parte3Tab);
            app.GridLayout2.ColumnWidth = {'1x', '7x', 20, '2x', '7x', 20, '1x'};
            app.GridLayout2.RowHeight = {'1x', 20, '1.2x', '1x', 5, '1x', 20, '1.2x', '1x'};
            app.GridLayout2.ColumnSpacing = 5;
            app.GridLayout2.RowSpacing = 5;

            % Create telemetriaPanel
            app.telemetriaPanel = uipanel(app.GridLayout2);
            app.telemetriaPanel.Layout.Row = [2 3];
            app.telemetriaPanel.Layout.Column = 2;

            % Create telemetriaLabel
            app.telemetriaLabel = uilabel(app.telemetriaPanel);
            app.telemetriaLabel.WordWrap = 'on';
            app.telemetriaLabel.FontName = 'Open Sans';
            app.telemetriaLabel.Position = [13 52 235 31];
            app.telemetriaLabel.Text = 'É necessário implementar um sistema de telemetria?';

            % Create telemetriaSwitch
            app.telemetriaSwitch = uiswitch(app.telemetriaPanel, 'slider');
            app.telemetriaSwitch.Items = {'Não', 'Sim'};
            app.telemetriaSwitch.ItemsData = [0 1];
            app.telemetriaSwitch.Position = [107 20 45 20];
            app.telemetriaSwitch.Value = 0;

            % Create telemetriaTooltip
            app.telemetriaTooltip = uilabel(app.GridLayout2);
            app.telemetriaTooltip.BackgroundColor = [0 0.4471 0.7412];
            app.telemetriaTooltip.HorizontalAlignment = 'center';
            app.telemetriaTooltip.FontWeight = 'bold';
            app.telemetriaTooltip.FontColor = [1 1 1];
            app.telemetriaTooltip.Tooltip = {'Neste projeto, a telemetria consiste em um conjunto de sensores para realizar a medição e a comunicação de informações referentes ao sistema fotovoltaico, como valores de corrente e de tensão, possibilitando o acompanhamento do desempeho do sistema a todo momento.'};
            app.telemetriaTooltip.Layout.Row = 2;
            app.telemetriaTooltip.Layout.Column = 3;
            app.telemetriaTooltip.Text = '?';

            % Create raspPanel
            app.raspPanel = uipanel(app.GridLayout2);
            app.raspPanel.TitlePosition = 'centertop';
            app.raspPanel.Layout.Row = [2 3];
            app.raspPanel.Layout.Column = 5;

            % Create raspLabel
            app.raspLabel = uilabel(app.raspPanel);
            app.raspLabel.WordWrap = 'on';
            app.raspLabel.FontName = 'Open Sans';
            app.raspLabel.Position = [10 45 244 43];
            app.raspLabel.Text = 'A equipe técnica tem familiaridade com o uso de microcomputadores, ex: Raspberry Pi?';

            % Create raspSwitch
            app.raspSwitch = uiswitch(app.raspPanel, 'slider');
            app.raspSwitch.Items = {'Não', 'Sim'};
            app.raspSwitch.ItemsData = [0 1];
            app.raspSwitch.Position = [105 19 45 20];
            app.raspSwitch.Value = 0;

            % Create raspTooltip
            app.raspTooltip = uilabel(app.GridLayout2);
            app.raspTooltip.BackgroundColor = [0 0.4471 0.7412];
            app.raspTooltip.HorizontalAlignment = 'center';
            app.raspTooltip.FontWeight = 'bold';
            app.raspTooltip.FontColor = [1 1 1];
            app.raspTooltip.Tooltip = {'Em alguns casos, o Raspberry Pi pode ser utilizado na construção de um sistema de monitoramento de porte pequeno com uma câmera de baixo consumo. Além disso, também pode atuar como núcleo do sistema de telemetria, oferecendo suporte para uma grande variedade de sensores. No entanto, microcomputadores são dispositivos mais complexos de configurar e operar, exigindo conhecimentos em programação, configuração de sistemas e integração de hardware. Essa complexidade pode representar um desafio para usuários sem experiência técnica.'};
            app.raspTooltip.Layout.Row = 2;
            app.raspTooltip.Layout.Column = 6;
            app.raspTooltip.Text = '?';

            % Create autonomiaPanel
            app.autonomiaPanel = uipanel(app.GridLayout2);
            app.autonomiaPanel.Title = 'Autonomia desejada para o sistema (h)';
            app.autonomiaPanel.Layout.Row = [7 8];
            app.autonomiaPanel.Layout.Column = 2;
            app.autonomiaPanel.FontName = 'Open Sans';

            % Create slider2dropButton_7
            app.slider2dropButton_7 = uibutton(app.autonomiaPanel, 'push');
            app.slider2dropButton_7.ButtonPushedFcn = createCallbackFcn(app, @slider2dropButton_7Pushed, true);
            app.slider2dropButton_7.VerticalAlignment = 'top';
            app.slider2dropButton_7.FontName = 'Liberation Sans';
            app.slider2dropButton_7.FontWeight = 'bold';
            app.slider2dropButton_7.Position = [8 30 20 20];
            app.slider2dropButton_7.Text = '';
            app.slider2dropButton_7.Icon = fullfile(pathToMLAPP, 'troca.png');

            % Create autonomiaSlider
            app.autonomiaSlider = uislider(app.autonomiaPanel);
            app.autonomiaSlider.Limits = [0 72];
            app.autonomiaSlider.MajorTicks = [0 12 24 36 48 60 72];
            app.autonomiaSlider.MajorTickLabels = {'0', '12', '24', '36', '48', '60', '72'};
            app.autonomiaSlider.MinorTicks = [0 2 4 6 8 10 12 14 16 18 20 22 24 26 28 30 32 34 36 38 40 42 44 46 48 50 52 54 56 58 60 62 64 66 68 70 72];
            app.autonomiaSlider.Position = [45 50 180 3];

            % Create autonomiaDropDown
            app.autonomiaDropDown = uidropdown(app.autonomiaPanel);
            app.autonomiaDropDown.Items = {'mínima', 'moderada', 'estendida'};
            app.autonomiaDropDown.Visible = 'off';
            app.autonomiaDropDown.Position = [45 31 180 22];
            app.autonomiaDropDown.Value = 'mínima';

            % Create autonomiaTooltip
            app.autonomiaTooltip = uilabel(app.GridLayout2);
            app.autonomiaTooltip.BackgroundColor = [0 0.4471 0.7412];
            app.autonomiaTooltip.HorizontalAlignment = 'center';
            app.autonomiaTooltip.FontWeight = 'bold';
            app.autonomiaTooltip.FontColor = [1 1 1];
            app.autonomiaTooltip.Tooltip = {'É o tempo durante qual o banco de baterias, totalmente carregado, assegura a continuidade de alimentação de energia à carga, quando não há geração de energia. Quanto maior for a autonomia desejada, maior deverá ser a capacidade do banco de baterias, o que implica no aumento do custo e da necessidade de espaço para a instalação.'};
            app.autonomiaTooltip.Layout.Row = 7;
            app.autonomiaTooltip.Layout.Column = 3;
            app.autonomiaTooltip.Text = '?';

            % Create estacaoCarregamentoPanel
            app.estacaoCarregamentoPanel = uipanel(app.GridLayout2);
            app.estacaoCarregamentoPanel.Layout.Row = [7 8];
            app.estacaoCarregamentoPanel.Layout.Column = 5;

            % Create estacaoCarregamentoLabel
            app.estacaoCarregamentoLabel = uilabel(app.estacaoCarregamentoPanel);
            app.estacaoCarregamentoLabel.WordWrap = 'on';
            app.estacaoCarregamentoLabel.FontName = 'Open Sans';
            app.estacaoCarregamentoLabel.FontSize = 11.8;
            app.estacaoCarregamentoLabel.Position = [7 40 244 52];
            app.estacaoCarregamentoLabel.Text = 'O programa deve considerar a possibilidade de substituição de parte dos equipamentos por uma estação de carregamento?';

            % Create estacaoCarregamentoSwitch
            app.estacaoCarregamentoSwitch = uiswitch(app.estacaoCarregamentoPanel, 'slider');
            app.estacaoCarregamentoSwitch.Items = {'Não', 'Sim'};
            app.estacaoCarregamentoSwitch.ItemsData = [0 1];
            app.estacaoCarregamentoSwitch.Position = [105 12 45 20];
            app.estacaoCarregamentoSwitch.Value = 0;

            % Create estacaoCarregamentoTooltip
            app.estacaoCarregamentoTooltip = uilabel(app.GridLayout2);
            app.estacaoCarregamentoTooltip.BackgroundColor = [0 0.4471 0.7412];
            app.estacaoCarregamentoTooltip.HorizontalAlignment = 'center';
            app.estacaoCarregamentoTooltip.FontWeight = 'bold';
            app.estacaoCarregamentoTooltip.FontColor = [1 1 1];
            app.estacaoCarregamentoTooltip.Tooltip = {'Uma estação de carregamento é uma tecnologia que agrega diversos equipamentos (bateria, controlador de carga, inversor) em um único item, tornando o sistema mais compacto. Em contrapartida, é um equipamento significativamente mais caro e pode não ser aplicável a todos os casos.'};
            app.estacaoCarregamentoTooltip.Layout.Row = 7;
            app.estacaoCarregamentoTooltip.Layout.Column = 6;
            app.estacaoCarregamentoTooltip.Text = '?';

            % Create divisioriaLabel_3
            app.divisioriaLabel_3 = uilabel(app.GridLayout2);
            app.divisioriaLabel_3.BackgroundColor = [0.902 0.902 0.902];
            app.divisioriaLabel_3.Layout.Row = 5;
            app.divisioriaLabel_3.Layout.Column = [1 7];
            app.divisioriaLabel_3.Text = '';

            % Create ResultadosTab
            app.ResultadosTab = uitab(app.TabGroup);
            app.ResultadosTab.Title = 'Resultados';

            % Create GridLayout3
            app.GridLayout3 = uigridlayout(app.ResultadosTab);
            app.GridLayout3.ColumnWidth = {'1x', 20, '1x'};
            app.GridLayout3.RowHeight = {'1x', 10, '1x', 10, '0.8x', 10, '0.8x'};
            app.GridLayout3.ColumnSpacing = 5;
            app.GridLayout3.RowSpacing = 5;
            app.GridLayout3.Padding = [15 10 15 20];

            % Create cameraPanel
            app.cameraPanel = uipanel(app.GridLayout3);
            app.cameraPanel.Title = 'Câmera';
            app.cameraPanel.Layout.Row = [1 3];
            app.cameraPanel.Layout.Column = 1;
            app.cameraPanel.FontName = 'Open Sans';
            app.cameraPanel.FontWeight = 'bold';

            % Create porteCameraLabel
            app.porteCameraLabel = uilabel(app.cameraPanel);
            app.porteCameraLabel.WordWrap = 'on';
            app.porteCameraLabel.FontName = 'Open Sans';
            app.porteCameraLabel.FontSize = 11.5;
            app.porteCameraLabel.Position = [7 80 332 67];
            app.porteCameraLabel.Text = '';

            % Create tipoCameraLabel
            app.tipoCameraLabel = uilabel(app.cameraPanel);
            app.tipoCameraLabel.WordWrap = 'on';
            app.tipoCameraLabel.FontName = 'Open Sans';
            app.tipoCameraLabel.FontSize = 11.5;
            app.tipoCameraLabel.Position = [7 152 332 66];
            app.tipoCameraLabel.Text = '';

            % Create obsLabel
            app.obsLabel = uilabel(app.cameraPanel);
            app.obsLabel.WordWrap = 'on';
            app.obsLabel.FontName = 'Open Sans';
            app.obsLabel.FontSize = 10.5;
            app.obsLabel.Visible = 'off';
            app.obsLabel.Position = [7 6 332 65];
            app.obsLabel.Text = 'OBS: o modelo escolhido deve possuir nível de proteção IP 66 ou IP 67 para garantir a durabilidade em ambientes externos. No caso de modelos compactos instalados em locais protegidos, o nível de proteção pode ser inferior, desde que o ambiente seja devidamente isolado de intempéries.';

            % Create tipoTelemetriaPanel
            app.tipoTelemetriaPanel = uipanel(app.GridLayout3);
            app.tipoTelemetriaPanel.Title = 'Sistema de telemetria';
            app.tipoTelemetriaPanel.Layout.Row = 5;
            app.tipoTelemetriaPanel.Layout.Column = 1;
            app.tipoTelemetriaPanel.FontName = 'Open Sans';
            app.tipoTelemetriaPanel.FontWeight = 'bold';

            % Create tipoTelemetriaLabel
            app.tipoTelemetriaLabel = uilabel(app.tipoTelemetriaPanel);
            app.tipoTelemetriaLabel.WordWrap = 'on';
            app.tipoTelemetriaLabel.FontName = 'Open Sans';
            app.tipoTelemetriaLabel.FontSize = 11.5;
            app.tipoTelemetriaLabel.Position = [7 6 332 58];
            app.tipoTelemetriaLabel.Text = '';

            % Create tipoBateriaPanel
            app.tipoBateriaPanel = uipanel(app.GridLayout3);
            app.tipoBateriaPanel.Title = 'Sobre o sistema fotovoltaico isolado da rede';
            app.tipoBateriaPanel.Layout.Row = [1 7];
            app.tipoBateriaPanel.Layout.Column = 3;
            app.tipoBateriaPanel.FontName = 'Open Sans';
            app.tipoBateriaPanel.FontWeight = 'bold';

            % Create tipoModuloLabel
            app.tipoModuloLabel = uilabel(app.tipoBateriaPanel);
            app.tipoModuloLabel.WordWrap = 'on';
            app.tipoModuloLabel.FontName = 'Open Sans';
            app.tipoModuloLabel.FontSize = 11.5;
            app.tipoModuloLabel.Position = [6 306 333 124];
            app.tipoModuloLabel.Text = '';

            % Create tipoBateriaLabel
            app.tipoBateriaLabel = uilabel(app.tipoBateriaPanel);
            app.tipoBateriaLabel.WordWrap = 'on';
            app.tipoBateriaLabel.FontName = 'Open Sans';
            app.tipoBateriaLabel.FontSize = 11.5;
            app.tipoBateriaLabel.Position = [6 195 333 106];
            app.tipoBateriaLabel.Text = '';

            % Create controladorLabel
            app.controladorLabel = uilabel(app.tipoBateriaPanel);
            app.controladorLabel.WordWrap = 'on';
            app.controladorLabel.FontName = 'Open Sans';
            app.controladorLabel.FontSize = 11.5;
            app.controladorLabel.Position = [6 108 333 82];
            app.controladorLabel.Text = '';

            % Create inversorLabel
            app.inversorLabel = uilabel(app.tipoBateriaPanel);
            app.inversorLabel.WordWrap = 'on';
            app.inversorLabel.FontName = 'Open Sans';
            app.inversorLabel.FontSize = 11.5;
            app.inversorLabel.Position = [6 31 333 70];
            app.inversorLabel.Text = '';

            % Create tipoConexaoPanel
            app.tipoConexaoPanel = uipanel(app.GridLayout3);
            app.tipoConexaoPanel.Title = 'Conexão à rede';
            app.tipoConexaoPanel.Layout.Row = 7;
            app.tipoConexaoPanel.Layout.Column = 1;
            app.tipoConexaoPanel.FontName = 'Open Sans';
            app.tipoConexaoPanel.FontWeight = 'bold';

            % Create tipoConexaoLabel
            app.tipoConexaoLabel = uilabel(app.tipoConexaoPanel);
            app.tipoConexaoLabel.WordWrap = 'on';
            app.tipoConexaoLabel.FontName = 'Open Sans';
            app.tipoConexaoLabel.FontSize = 11.5;
            app.tipoConexaoLabel.Position = [7 4 332 60];
            app.tipoConexaoLabel.Text = '';

            % Create executarButton
            app.executarButton = uibutton(app.UIFigure, 'push');
            app.executarButton.ButtonPushedFcn = createCallbackFcn(app, @executarButtonPushed, true);
            app.executarButton.BackgroundColor = [0.9412 0.9412 0.9412];
            app.executarButton.FontName = 'SansSerif';
            app.executarButton.FontWeight = 'bold';
            app.executarButton.Interpreter = 'html';
            app.executarButton.Position = [778 147 169 43];
            app.executarButton.Text = '&#9654   EXECUTAR ';

            % Create salvarButton
            app.salvarButton = uibutton(app.UIFigure, 'push');
            app.salvarButton.ButtonPushedFcn = createCallbackFcn(app, @salvarButtonPushed, true);
            app.salvarButton.FontName = 'SansSerif';
            app.salvarButton.FontSize = 11;
            app.salvarButton.FontWeight = 'bold';
            app.salvarButton.Position = [788 86 150 36];
            app.salvarButton.Text = 'SALVAR RESULTADOS';

            % Create anteriorButton
            app.anteriorButton = uibutton(app.UIFigure, 'push');
            app.anteriorButton.ButtonPushedFcn = createCallbackFcn(app, @anteriorButtonPushed, true);
            app.anteriorButton.BackgroundColor = [0 0.4471 0.7412];
            app.anteriorButton.FontSize = 18;
            app.anteriorButton.FontWeight = 'bold';
            app.anteriorButton.FontColor = [1 1 1];
            app.anteriorButton.Interpreter = 'tex';
            app.anteriorButton.Position = [778 15 42 33];
            app.anteriorButton.Text = '\leftarrow';

            % Create proximoButton
            app.proximoButton = uibutton(app.UIFigure, 'push');
            app.proximoButton.ButtonPushedFcn = createCallbackFcn(app, @proximoButtonPushed, true);
            app.proximoButton.BackgroundColor = [0 0.4471 0.7412];
            app.proximoButton.FontSize = 18;
            app.proximoButton.FontWeight = 'bold';
            app.proximoButton.FontColor = [1 1 1];
            app.proximoButton.Interpreter = 'latex';
            app.proximoButton.Position = [825 15 42 33];
            app.proximoButton.Text = '\rightarrow';

            % Create backgroundTextArea
            app.backgroundTextArea = uitextarea(app.UIFigure);
            app.backgroundTextArea.Editable = 'off';
            app.backgroundTextArea.BackgroundColor = [0.9412 0.9412 0.9412];
            app.backgroundTextArea.Position = [778 232 169 271];

            % Create dicasTextArea
            app.dicasTextArea = uitextarea(app.UIFigure);
            app.dicasTextArea.Editable = 'off';
            app.dicasTextArea.FontName = 'Open Sans';
            app.dicasTextArea.FontWeight = 'bold';
            app.dicasTextArea.BackgroundColor = [0.9412 0.9412 0.9412];
            app.dicasTextArea.Position = [778 503 169 24];
            app.dicasTextArea.Value = {'DICAS'};

            % Create dicasLabel
            app.dicasLabel = uilabel(app.UIFigure);
            app.dicasLabel.WordWrap = 'on';
            app.dicasLabel.FontName = 'Open Sans';
            app.dicasLabel.FontSize = 11;
            app.dicasLabel.Position = [787 237 153 261];
            app.dicasLabel.Text = {'1. Posicione o cursor do mouse sobre o ícone (?) ao lado de cada pergunta para visualizar uma explicação mais detalhada sobre o que está sendo solicitado.'; ''; '2. Em algumas perguntas, também existe um ícone ⚙️ que, ao ser clicado, alterna entre dois formatos de resposta. Assim, o usuário pode optar por utilizar valores numéricos ou termos linguísticos, que são mais generalizados e podem simplificar a resposta quando os valores exatos não forem conhecidos.'};

            % Show the figure after all components are created
            app.UIFigure.Visible = 'on';
        end
    end

    % App creation and deletion
    methods (Access = public)

        % Construct app
        function app = interface_sef

            % Create UIFigure and components
            createComponents(app)

            % Register the app with App Designer
            registerApp(app, app.UIFigure)

            if nargout == 0
                clear app
            end
        end

        % Code that executes before app deletion
        function delete(app)

            % Delete UIFigure when app is deleted
            delete(app.UIFigure)
        end
    end
end